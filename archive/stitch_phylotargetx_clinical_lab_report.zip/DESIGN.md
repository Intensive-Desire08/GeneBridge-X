---
name: Clinical Ethereal
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3f4850'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#b90538'
  on-tertiary: '#ffffff'
  tertiary-container: '#dc2c4f'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.25rem
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-trust, sterile yet atmospheric visual environment tailored for computational oncology, clinical bioinformatics, and precision medicine. The design language merges clinical rigor with an airy, weightless aesthetic ("Clinical Ethereal"). 

It combines translucent laboratory glassmorphism with tactile diagnostics artifacts—specifically inspired by high-precision thermal printouts, chromatographic strips, and diagnostic assay readouts. The interface inspires total diagnostic certitude, eliminating cognitive clutter while maintaining strict computational transparency. Monospaced molecular annotations juxtaposed against balanced humanist body typography create a distinct rhythm suited for oncologists and translational scientists navigating complex patient sequencing panels.

## Colors

The palette grounds the interface in clinical clarity, using restrained atmospheric base layers with focused diagnostic accents:

- **Atmospheric Canvas**: Transitions from Soft Alabaster (`#FAFAFA`) to Pale Clinical Blue (`#F0F4F8`). This ambient gradient must remain subtle, providing depth beneath frosted glass surfaces without skewing optical contrast.
- **Surfaces**: Frosted laboratory white (`rgba(255, 255, 255, 0.90)`) reinforced with hairline borders in tinted slate (`rgba(226, 232, 240, 0.90)`).
- **Primary Diagnostics (`#0284C7`)**: Clinical Cyan/Deep Sky for primary platform actions, target trajectory navigations, and selected chromosome/variant states.
- **Secondary / Efficacy Affinity (`#10B981` / `#A3C9A8`)**: Soft Sage Green signaling top AI confidence, high genomic match affinity, favourable $\Delta G$ scores, and actionable therapeutic matches.
- **Tertiary / Clinical Alert (`#F43F5E` / `#FFA69E`)**: Soft Coral/Salmon indicating contraindications, high adverse reaction risk, pathogenic classifications, or low confidence binding.
- **Neutral Core (`#0F172A`)**: Deep Slate/Obsidian for high-contrast legible clinical narratives, genomic tables, and critical lab values.

## Typography

Typography establishes clear categorical separation between medical narrative interpretation and deterministic scientific computation:

- **Headings (Plus Jakarta Sans)**: Delivers a clean, contemporary clinical air. Used for patient case headers, report sections, and module titles.
- **Narrative & Diagnostic Prose (Inter)**: Delivers neutral, transparent clarity for clinical recommendations, therapeutic rationale, and pathologist notes.
- **Scientific & Data Values (JetBrains Mono)**: Applied universally to all machine outputs, raw bioinformatics identifiers, structural data, and chain verifications: PDB IDs (`e.g., 7L10`), ChEMBL IDs (`e.g., CHEMBL25`), dissociation constants ($K_d$), free energy ($\Delta G$), patient run timestamps, sequencing coordinates, and SHA-256 audit ledger hashes.

## Layout & Spacing

The layout is built on a 12-column fluid grid system paired with an 8pt architectural rhythm. 

- **Desktop (>= 1280px)**: 12-column configuration with a 2.5rem outer canvas margin and 1.5rem gutters. Clinical reporting views enforce a structured split: 4 columns for sticky genomic navigation/patient triage telemetry and 8 columns for the therapeutic dossier and affinity analysis.
- **Tablet (768px - 1279px)**: 8-column layout with 1.5rem margins and 1rem gutters. Left-hand telemetry collapses into a tabbed sticky secondary bar.
- **Mobile (< 768px)**: 4-column layout with 1rem margins and 1rem gutters. Data tables collapse to atomic laboratory receipt cards with horizontal scrolling enabled specifically for sequence ribbons.

## Elevation & Depth

Visual hierarchy leverages frosted layered translucency combined with crisp optical drop shadows.

- **Base Ambient Canvas**: A non-scrolling radial gradient mesh flowing from Soft Alabaster (`#FAFAFA`) to Pale Clinical Blue (`#F0F4F8`).
- **Layer 1 (Containers & Panels)**: Background `rgba(255, 255, 255, 0.90)`, `backdrop-filter: blur(24px)`, enclosed in hairline borders `border: 1px solid rgba(226, 232, 240, 0.90)`. Shadow: `0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 1px 3px 0 rgba(15, 23, 42, 0.02)`.
- **Layer 2 (Interactive Modules & Flyouts)**: Background `rgba(255, 255, 255, 0.96)`, `backdrop-filter: blur(32px)`, with subtle elevated drop shadows: `0 12px 32px -4px rgba(15, 23, 42, 0.07), 0 4px 8px -2px rgba(15, 23, 42, 0.03)`.
- **Layer 3 (Modal Alerts & Molecular Overlays)**: Pure clinical white (`#FFFFFF`) with deep containment shadow: `0 24px 48px -12px rgba(15, 23, 42, 0.12)`.

## Shapes

The design uses tight, technical corners (`roundedness: 1` — base 0.25rem, containers 0.5rem) to evoke precision lab instruments, microfluidic chips, and clean-cut diagnostics. 

To reinforce the laboratory receipt aesthetic:
- Report dividers and tear-off sections feature a CSS-masked perforated edge pattern (alternating 4px transparent punch-outs on a 12px repeat) or crisp dashed lines (`border-style: dashed; border-color: rgba(203, 213, 225, 0.8)`).
- Summary report headers display synthetic barcode/matrix tracking marks in the top-right corner to simulate certified clinical documentation.

## Components

### Buttons
- **Primary Lab Action**: Deep Clinical Blue background (`#0284C7`), text white, crisp radius (`0.25rem`), font weight 600. Subtle shadow: `0 1px 2px rgba(2, 132, 199, 0.2)`. On hover: `#0369A1`.
- **Secondary / Ghost**: White translucent fill (`rgba(255, 255, 255, 0.80)`), 1px solid border (`#CBD5E1`), text `#0F172A`. On hover: `rgba(240, 244, 248, 0.80)`.
- **Destructive / Flag**: `#F43F5E` background or tinted ghost button with text `#E11D48`.

### Diagnostic Chips & Variant Badges
- Strict monospaced text rendering (`JetBrains Mono`, 0.75rem).
- **High AI Confidence / Top Match**: Pale sage background (`rgba(163, 201, 168, 0.22)`), text `#065F46`, border `1px solid rgba(16, 185, 129, 0.35)`.
- **Low Confidence / Adverse Variant**: Pale salmon background (`rgba(255, 166, 158, 0.25)`), text `#9F1239`, border `1px solid rgba(244, 63, 94, 0.35)`.
- **Structural Identity (PDB/ChEMBL)**: Slate neutral background (`rgba(241, 245, 249, 0.9)`), text `#334155`, border `1px solid #E2E8F0`.

### Cards & Laboratory Receipt Modules
- **Container Structure**: `bg-white/90`, `backdrop-blur-2xl`, 1px solid `slate-200/90`.
- **Receipt Aesthetic**: Cards summarizing mutation affinity or drug-protein binding include a dashed divider (`border-t border-dashed border-slate-300`) separating molecular metadata from the clinical conclusion. Lower card margins can feature a fine serrated or notched SVG mask to complete the thermal paper motif.

### Form Inputs & Bio-Search Bars
- Rectangular with micro-radius (`0.25rem`). Frosted fill (`rgba(255, 255, 255, 0.85)`), border `1px solid #CBD5E1`.
- Focus state: Outline zero, box-shadow ring `0 0 0 2px rgba(2, 132, 199, 0.25)`, border-color `#0284C7`. Placeholder text in `#94A3B8`.

### Checkboxes & Selectors
- Rigid square (`0.25rem` radius), crisp border (`#94A3B8`). Selected state fills with `#0284C7` sporting a sharp white clinical checkmark.

### Domain-Specific Components
- **Binding Affinity Gauge Strip**: A horizontal segmented bar displaying predicted $\Delta G$ values, transitioning smoothly from Salmon (`-4.0 kcal/mol`) to Sage Green (`-12.0 kcal/mol`).
- **Cryptographic Audit Ribbon**: A bottom bar on clinical dossiers displaying the SHA-256 validation hash and sequencing timestamp in `JetBrains Mono` at 0.6875rem with an unpunched perforated top border.